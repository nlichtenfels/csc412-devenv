#include <stdio.h>
#include <stdlib.h>

/**

TODO Part 1:

In this file, you will write multiple functions:

1. reverse_arr1: will take in two inputs a char** array and the number of
elements in the array. It's responsible for reversing the input array. You
should be modifying this array in place. Meaning that you shouldn't returning anything from this function. See aren't pointers convenient?

2. swap: will take in two elements from the array and swap them. Returns nothing.

Example:
Given an array ["hello", "my", "name", "is"], after calling reverse_arr1 will result in ["is", "name", "my", "hello"]

Then move on to reverse strings using the functions reverse_str1 and swap_chr. You will be doing the same thing as above, but instead of an array of strings, you will be reversing a single string.

FINALLY, implement as many of the other functions you can to pass at least 40 of the tests we include here.

*/

// use this function in your reverse_arr functions
void swap(char** a, char** b) {

}

// use this function in your reverse_str functions
void swap_chr(char* a, char* b) {

}

/**
 TODO: I need comments describing what I do :(
 */
void reverse_arr1(char** arr, int size) {

}

/**
 TODO: I need comments describing what I do :(
 */
void reverse_arr2(char** arr, int size) {

}

/**
 TODO: I need comments describing what I do :(
 */
void reverse_arr3(char** arr, int size) {

}

/**
 TODO: I need comments describing what I do :(
 */
void reverse_arr4(char** arr, int size) {

}

/**
 TODO: I need comments describing what I do :(
 */
void reverse_arr5(char** arr, int size) {

}

/**
 TODO: I need comments describing what I do :(
 */
void reverse_str1(char* str, int size) {

}

/**
 TODO: I need comments describing what I do :(
 */
void reverse_str2(char* str, int size) {

}

/**
 TODO: I need comments describing what I do :(
 */
void reverse_str3(char* str, int size) {

}

/**
 TODO: I need comments describing what I do :(
 */
void reverse_str4(char* str, int size) {

}

/**
 TODO: I need comments describing what I do :(
 */
void reverse_str5(char* str, int size) {
    
}