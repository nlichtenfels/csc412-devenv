# URI CSC 412 - Spring 24 Assignments

This is where the stencil code for the assignments lives :)
