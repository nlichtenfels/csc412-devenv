#include <stdio.h>

int main() {
   char msg[] = "Hello, World!";
   // printf will print the text to the screen in the terminal (CLI)
   printf("%s", msg);
   return 0; // return 1 if something went wrong
}