#include <stdio.h>

int main() {
    // define the incoming stream of page references
    int incomingStream[] = {4, 1, 2, 4, 5};
    int pageFaults = 0;
    int frames = 3;
    int m, n, s, pages;
    
    // calculate the number of pages in the incoming stream
    pages = sizeof(incomingStream) / sizeof(incomingStream[0]);

    // print the header for the output table
    printf(" Incoming \t Frame 1 \t Frame 2 \t Frame 3 ");

    // initialize an array to represent the frames with -1 (empty)
    int temp[frames];
    for (m = 0; m < frames; m++) {
        temp[m] = -1;
    }

    for (m = 0; m < pages; m++) {
        s = 0;
        for (n = 0; n < frames; n++) {
            // check if the incoming page is already in a frame
            if (incomingStream[m] == temp[n]) {
                s++;
                // decrement pageFaults
                pageFaults--;
            }
        }
        // increment pageFaults for the current page reference
        pageFaults++;

        if ((pageFaults <= frames) && (s == 0)) {
            // if there are empty frames and the page is not in any of them, 
            // put it in an empty frame
            temp[m] = incomingStream[m];
        } else if (s == 0) {
            // if all frames are occupied, 
            // replace one of them using FIFO replacement
            temp[(pageFaults - 1) % frames] = incomingStream[m];
        }

        // current state of frames after processing the page reference
        printf("\n");
        printf("%d\t\t\t", incomingStream[m]);
        for (n = 0; n < frames; n++) {
            if (temp[n] != -1) {
                printf(" %d\t\t\t", temp[n]);
            } else {
                printf(" - \t\t\t"); // "-" represents empty frames
            }
        }
    }

    printf("\nTotal Page Faults:\t%d\n", pageFaults);
    return 0;
}
