### hackings

FIX
strncpy(buffer, argv[2], BUFFERSIZE); // good :)

csc412-user@c44df2bbf71b:~/lectures/hacking$ ./main password 0123456789012345password

### strings

shaunwallace@181 hacking % strings main
usage %s <password> <string_to_print>
password checks out
MSG: %s
password error!
message
passw0rd


### objdump

csc412-user@c44df2bbf71b:~/lectures/hacking$ objdump -t ./main

./main:     file format elf64-littleaarch64

SYMBOL TABLE:
0000000000000000       F *UND*  0000000000000000              __libc_start_main@@GLIBC_2.17
0000000000011020 g     O .data  000000000000000a              password
0000000000011010 g     O .data  000000000000000a              buffer
0000000000011000 g       .data  0000000000000000              __data_start

