#include <stdio.h>
#include <unistd.h>

int n = 0;

int main() {
    printf("n=%d :: pointer = %p\n", n, &n);

    return 0;
}
