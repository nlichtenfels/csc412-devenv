### hackings fork bomb

Run on Linux
    Address
    Then: objdump -t ./main
    Run twice ./main & ./main

Run on Linux with Loop
    Numbers not adding up correctly?
    Virtual Address (Logical Address) vs Physical Address

Run on Mac
    uh oh, different Virtual Addresses
    Address Space Randomization
    -Wl, -no_pie
