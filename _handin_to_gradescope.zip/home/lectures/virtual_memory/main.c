#include <stdio.h>

//int globalVar = 4;
int globalVar2 = 4;

int main() {
    int localVar = 1;

    //printf("Address of globalVar: %p\n", (void*)&globalVar);
    printf("Address of globalVar: %p\n", (void*)&globalVar2);
    printf("Address of localVar: %p\n", (void*)&localVar);

    return 0;
}
